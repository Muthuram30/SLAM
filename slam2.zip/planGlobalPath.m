function [path, planInfo] = planGlobalPath(map, startPose, goalXY, config)
%PLANGLOBALPATH Plan a collision-free path from startPose to goalXY using A*.
%
%   [path, planInfo] = PLANGLOBALPATH(map, startPose, goalXY, config)
%
%   Implements 8-connected A* over an inflated binaryOccupancyMap.
%
%   Cell cost model:
%       Free cell     : 1.0  (or 1.414 for diagonal)
%       Unknown cell  : config.unknownCellCost × base cost
%       Occupied cell : not traversable (treated as wall)
%
%   After A* succeeds, the raw grid path is:
%       1. Converted to world coordinates.
%       2. Optionally smoothed with Douglas-Peucker simplification.
%       3. Optionally shortcut-pruned (direct line-of-sight between
%          non-adjacent points, using the inflated map as obstacle check).
%
%   Fallback when no path is found:
%       planInfo.noPathReason explains why:
%           'goal_in_unknown'  — goal cell is unknown; move toward boundary
%           'no_feasible_path' — known map has no path; escalate to recovery
%           'goal_occupied'    — goal is inside an inflated obstacle
%
%   Inputs:
%       map      - binaryOccupancyMap (ground truth or SLAM, not pre-inflated)
%       startPose - 1×3 [x y theta] robot pose in world frame
%       goalXY    - 1×2 [x y] goal position in world frame
%       config    - config.globalPlanner struct (see main.m)
%
%   Outputs:
%       path     - Nx2 world-frame [x y] ordered path, or [] if no path
%       planInfo - struct:
%           .success         true if path found
%           .noPathReason    string (empty when success)
%           .expandedNodes   number of A* nodes expanded
%           .rawPathLength   path length before smoothing (m)
%           .smoothPathLength path length after smoothing (m)
%           .planTimeMs      planning time (ms)
%           .goalInUnknown   true if goal cell was unknown
%
%   Config fields (config.globalPlanner):
%       .inflationRadius    - obstacle inflation radius (m), default 0.25
%       .safetyMargin       - extra inflation beyond robot radius (m), default 0.05
%       .unknownCellCost    - cost multiplier for unknown cells, default 5.0
%       .pathSmoothing      - enable Douglas-Peucker simplification, default true
%       .smoothingEpsilon   - D-P tolerance (m), default 0.08
%       .shortcutPruning    - enable line-of-sight shortcutting, default true
%
%   Coordinate convention: world frame, x right, y up, row 1 = max-y.

    planTic = tic;

    % ---------------------------------------------------------------
    % Default config
    % ---------------------------------------------------------------
    if nargin < 4 || isempty(config)
        config = struct();
    end
    config = applyDefaults(config, struct( ...
        'inflationRadius',   0.25, ...
        'safetyMargin',      0.05, ...
        'unknownCellCost',   5.0,  ...
        'pathSmoothing',     true, ...
        'smoothingEpsilon',  0.08, ...
        'shortcutPruning',   true));

    % ---------------------------------------------------------------
    % Inflate the map
    % ---------------------------------------------------------------
    
    totalInflation = config.inflationRadius + config.safetyMargin;
    inflatedMap    = inflateOccupancyGrid(map, totalInflation);

    resolution = inflatedMap.Resolution;
    xLimits    = inflatedMap.XWorldLimits;
    yLimits    = inflatedMap.YWorldLimits;
    
    % Raw occupancy grid (logical: true = occupied/blocked)
    rawGrid  = logical(getOccupancy(inflatedMap));
    origGrid = logical(getOccupancy(map));  % for unknown detection
    [numRows, numCols] = size(rawGrid);

    % ---------------------------------------------------------------
    % Convert world positions to grid indices
    % Helper: worldToGrid returns (row, col) in binaryOccupancyMap convention
    % ---------------------------------------------------------------
    startXY = startPose(1:2);

    startRC = worldToGridRC(startXY, numRows, resolution);
    goalRC  = worldToGridRC(goalXY,  numRows, resolution);

    % Clamp to valid range
    startRC = clampRC(startRC, numRows, numCols);
    goalRC  = clampRC(goalRC,  numRows, numCols);

    % ---------------------------------------------------------------
    % Pre-check: classify goal cell
    % ---------------------------------------------------------------
    goalInUnknown = isUnknownCell(origGrid, inflatedMap, goalXY, numRows, resolution, xLimits, yLimits);
    goalOccupied  = rawGrid(goalRC(1), goalRC(2));

    planInfo = struct( ...
        'success',          false, ...
        'noPathReason',     '', ...
        'expandedNodes',    0, ...
        'rawPathLength',    0, ...
        'smoothPathLength', 0, ...
        'planTimeMs',       0, ...
        'goalInUnknown',    goalInUnknown);

    if goalOccupied && ~goalInUnknown
        path = [];
        planInfo.noPathReason = 'goal_occupied';
        planInfo.planTimeMs   = toc(planTic) * 1000;
        return;
    end

    % If start is in occupied space (shouldn't happen, but guard it)
    if rawGrid(startRC(1), startRC(2))
        % Try to nudge start to nearest free cell
        startRC = findNearestFree(rawGrid, startRC, numRows, numCols);
        if isempty(startRC)
            path = [];
            planInfo.noPathReason = 'start_occupied';
            planInfo.planTimeMs   = toc(planTic) * 1000;
            return;
        end
    end

    % ---------------------------------------------------------------
    % Build cost grid
    %   free cell = 1.0
    %   unknown   = unknownCellCost (high, but traversable)
    %   occupied  = Inf
    % ---------------------------------------------------------------
    % Detect unknown cells: cells that are free in the inflated map but
    % were never observed (occupancy value == 0.5 or NaN in orig map).
    % For binaryOccupancyMap, unobserved cells keep occupancy 0 (free by
    % default). We rely on origGrid being 0 for unobserved when the SLAM
    % map is used. For ground truth, everything is known, so unknownCost
    % has no effect.
    % Build the unknown-cell mask using the dedicated helper.
    % (origGrid and rawGrid may differ in dimensions after inflation so we
    %  do NOT directly mix them with &/| operators here.)
    unknownMask = buildUnknownMask(map, rawGrid, numRows, numCols, resolution, xLimits, yLimits);

    costGrid = ones(numRows, numCols);
    costGrid(rawGrid)      = Inf;                          % occupied → blocked
    costGrid(unknownMask)  = config.unknownCellCost;       % unknown  → high cost

    % ---------------------------------------------------------------
    % A* search (8-connected)
    % ---------------------------------------------------------------
    [gridPath, expandedNodes] = astarSearch(costGrid, startRC, goalRC, numRows, numCols);

    planInfo.expandedNodes = expandedNodes;

    if isempty(gridPath)
        path = [];
        if goalInUnknown
            planInfo.noPathReason = 'goal_in_unknown';
        else
            planInfo.noPathReason = 'no_feasible_path';
        end
        planInfo.planTimeMs = toc(planTic) * 1000;
        return;
    end

    % ---------------------------------------------------------------
    % Convert grid path to world coordinates
    % ---------------------------------------------------------------
    worldPath = gridToWorld(gridPath, numRows, resolution);

    % Measure raw path length
    planInfo.rawPathLength = pathLength(worldPath);

    % ---------------------------------------------------------------
    % Optional: Douglas-Peucker path smoothing
    % ---------------------------------------------------------------
    if config.pathSmoothing && size(worldPath, 1) > 2
        worldPath = douglasPeucker(worldPath, config.smoothingEpsilon);
    end

    % ---------------------------------------------------------------
    % Optional: line-of-sight shortcut pruning
    % ---------------------------------------------------------------
    if config.shortcutPruning && size(worldPath, 1) > 2
        worldPath = shortcutPrune(worldPath, rawGrid, numRows, resolution, ...
            totalInflation, xLimits, yLimits);
    end

    planInfo.smoothPathLength = pathLength(worldPath);
    planInfo.success          = true;
    planInfo.noPathReason     = '';
    planInfo.planTimeMs       = toc(planTic) * 1000;

    path = worldPath;
end


% =====================================================================
% A* Search (8-connected)
% =====================================================================
function [path, expandedNodes] = astarSearch(costGrid, startRC, goalRC, numRows, numCols)
%ASTARSEARCH 8-connected A* on costGrid. Returns Nx2 [row, col] path.

    expandedNodes = 0;

    % Priority queue via sorted array of structs.
    % State: [row, col, gCost, fCost, parentIdx]
    % Use min-heap (implemented as a sorted cell array for simplicity).

    totalCells = numRows * numCols;

    % gCost: cost from start to each cell (Inf = unvisited)
    gCost = inf(numRows, numCols);
    gCost(startRC(1), startRC(2)) = 0;

    % parent: linear index of parent cell (-1 = no parent)
    parent = -ones(numRows, numCols, 'int32');

    % Open set: min-heap by fCost.  Store linear indices.
    % Use a simple sorted vector approach (acceptable for maps < 200k cells).
    openF    = zeros(totalCells, 1);   % fCost for open nodes
    openIdx  = zeros(totalCells, 1, 'int32'); % linear cell index
    openSize = 0;

    goalLinear  = sub2ind([numRows, numCols], goalRC(1),  goalRC(2));
    startLinear = sub2ind([numRows, numCols], startRC(1), startRC(2));

    % Push start
    h0 = heuristic(startRC, goalRC);
    openSize = openSize + 1;
    openF(openSize)   = h0;
    openIdx(openSize) = startLinear;

    % 8-connected neighbors: [dRow, dCol, baseCost]
    neighbors = [-1 0; 1 0; 0 -1; 0 1; -1 -1; -1 1; 1 -1; 1 1];  % double, not int8
    baseCosts = [1; 1; 1; 1; 1.414; 1.414; 1.414; 1.414];

    closed = false(numRows, numCols);

    found = false;

    while openSize > 0
        % Pop minimum fCost node
        [~, minPos] = min(openF(1:openSize));
        currentLinear = openIdx(minPos);

        % Remove from open (swap with last)
        openF(minPos)   = openF(openSize);
        openIdx(minPos) = openIdx(openSize);
        openSize = openSize - 1;

        if currentLinear == goalLinear
            found = true;
            break;
        end

        [cr, cc] = ind2sub([numRows, numCols], currentLinear);

        if closed(cr, cc)
            continue;
        end
        closed(cr, cc) = true;
        expandedNodes  = expandedNodes + 1;

        currentG = gCost(cr, cc);

        for k = 1:8
            nr = cr + neighbors(k, 1);
            nc = cc + neighbors(k, 2);

            if nr < 1 || nr > numRows || nc < 1 || nc > numCols
                continue;
            end
            if closed(nr, nc)
                continue;
            end

            cellCost = costGrid(nr, nc);
            if isinf(cellCost)
                continue;  % blocked cell
            end

            tentativeG = currentG + baseCosts(k) * cellCost;

            if tentativeG < gCost(nr, nc)
                gCost(nr, nc)  = tentativeG;
                parent(nr, nc) = int32(currentLinear);

                h   = heuristic([nr, nc], goalRC);
                fCost = tentativeG + h;

                % Push to open
                openSize = openSize + 1;
                if openSize > numel(openF)
                    % Grow buffer (rare)
                    openF   = [openF;   zeros(totalCells, 1)];  %#ok<AGROW>
                    openIdx = [openIdx; zeros(totalCells, 1, 'int32')]; %#ok<AGROW>
                end
                openF(openSize)   = fCost;
                openIdx(openSize) = int32(sub2ind([numRows, numCols], nr, nc));
            end
        end
    end

    if ~found
        path = [];
        return;
    end

    % Reconstruct path by tracing parents back to start
    path = zeros(totalCells, 2, 'int32');
    pathLen = 0;
    cur = goalLinear;

    while cur ~= startLinear
        pathLen = pathLen + 1;
        [r, c] = ind2sub([numRows, numCols], cur);
        path(pathLen, :) = [r, c];
        cur = parent(r, c);
        if cur == -1
            path = [];
            return;
        end
    end
    % Append start
    pathLen = pathLen + 1;
    path(pathLen, :) = startRC;

    % Reverse to get start→goal order
    path = path(pathLen:-1:1, :);
    path = path(1:pathLen, :);
end


% =====================================================================
% Euclidean heuristic for A*
% =====================================================================
function h = heuristic(rc, goalRC)
    h = sqrt((rc(1) - goalRC(1))^2 + (rc(2) - goalRC(2))^2);
end


% =====================================================================
% Douglas-Peucker path simplification
% =====================================================================
function simplified = douglasPeucker(points, epsilon)
%DOUGLASPEUCKER Ramer-Douglas-Peucker polyline simplification.
%   Reduces the number of path points while preserving shape within epsilon.

    if size(points, 1) <= 2
        simplified = points;
        return;
    end

    simplified = dp_recursive(points, epsilon);
end

function result = dp_recursive(pts, epsilon)
    n = size(pts, 1);
    if n <= 2
        result = pts;
        return;
    end

    % Find point with max distance from line start→end
    p1 = pts(1, :);
    p2 = pts(n, :);
    v  = p2 - p1;
    vLen = norm(v);

    if vLen < 1e-9
        dists = vecnorm(pts(2:n-1, :) - p1, 2, 2);
    else
        vUnit = v / vLen;
        proj  = (pts(2:n-1, :) - p1) * vUnit';
        perpVec = (pts(2:n-1, :) - p1) - proj * vUnit;
        dists = vecnorm(perpVec, 2, 2);
    end

    [maxDist, maxIdx] = max(dists);
    maxIdx = maxIdx + 1;  % offset because we skipped first point

    if maxDist > epsilon
        left  = dp_recursive(pts(1:maxIdx, :), epsilon);
        right = dp_recursive(pts(maxIdx:end, :), epsilon);
        result = [left(1:end-1, :); right];
    else
        result = [p1; p2];
    end
end


% =====================================================================
% Line-of-sight shortcut pruning
% =====================================================================
function pruned = shortcutPrune(worldPath, rawGrid, numRows, resolution, checkRadius, xLimits, yLimits)
%SHORTCUTPRUNE Remove intermediate path points where direct line-of-sight exists.

    n = size(worldPath, 1);
    if n <= 2
        pruned = worldPath;
        return;
    end

    pruned = worldPath(1, :);
    i = 1;

    while i < n
        % Try to connect i directly to the furthest j with clear LOS
        j = i + 1;
        lastClear = j;
        while j <= n
            if segmentIsClear(worldPath(i,:), worldPath(j,:), rawGrid, numRows, resolution, xLimits, yLimits)
                lastClear = j;
                j = j + 1;
            else
                break;
            end
        end
        i = lastClear;
        pruned = [pruned; worldPath(i, :)]; %#ok<AGROW>
    end
end

function clear = segmentIsClear(p1, p2, rawGrid, numRows, resolution, xLimits, yLimits)
%SEGMENTISCLEAR Sample along segment p1→p2 and check occupancy.
    vec = p2 - p1;
    dist = norm(vec);
    if dist < 1e-6
        clear = true;
        return;
    end
    numSamples = max(2, ceil(dist * resolution));
    t = linspace(0, 1, numSamples)';
    pts = p1 + t * vec;

    clear = true;
    for k = 1:numSamples
        px = pts(k, 1);
        py = pts(k, 2);
        if px < xLimits(1) || px > xLimits(2) || py < yLimits(1) || py > yLimits(2)
            clear = false;
            return;
        end
        col = round(px * resolution) + 1;
        row = numRows - round(py * resolution);
        row = max(1, min(numRows, row));
        col = max(1, min(size(rawGrid, 2), col));
        if rawGrid(row, col)
            clear = false;
            return;
        end
    end
end


% =====================================================================
% Coordinate conversion helpers
% =====================================================================
function rc = worldToGridRC(xy, numRows, resolution)
%WORLDTOGRIDRC Convert world (x,y) to grid [row, col].
    col = round(xy(1) * resolution) + 1;
    row = numRows - round(xy(2) * resolution);
    rc  = [row, col];
end

function rc = clampRC(rc, numRows, numCols)
    rc(1) = max(1, min(numRows, rc(1)));
    rc(2) = max(1, min(numCols, rc(2)));
end

function worldPath = gridToWorld(gridPath, numRows, resolution)
%GRIDTOWORLD Convert Nx2 [row,col] grid path to Nx2 [x,y] world path.
    n = size(gridPath, 1);
    worldPath = zeros(n, 2);
    for k = 1:n
        r = gridPath(k, 1);
        c = gridPath(k, 2);
        worldPath(k, 1) = (c - 1) / resolution;
        worldPath(k, 2) = (numRows - r) / resolution;
    end
end


% =====================================================================
% Unknown cell detection
% =====================================================================
function mask = buildUnknownMask(map, rawGrid, numRows, numCols, resolution, xLimits, yLimits)
%BUILDUNKNOWNMASK Identify cells that are free in the occupancy map but
%have never been observed (unknown space).
%
%   For binaryOccupancyMap (ground truth): all cells are known → no unknowns.
%   For SLAM-built maps: unobserved cells have occupancy 0 by default, same
%   as known-free. We detect them by sampling the ORIGINAL (non-inflated)
%   occupancyMap at higher precision if available.
%
%   In practice, for binaryOccupancyMap the distinction is not possible
%   without an explicit observed-mask. We mark cells as unknown when
%   occupancy == 0 AND they fall in the map's unobserved region.
%   For simplicity, we set mask to all-false for binaryOccupancyMap (all
%   known), and rely on the caller to pass a SLAM map for unknown-cell cost.

    % binaryOccupancyMap does not distinguish observed-free from unknown.
    % We use a heuristic: cells at default occupancy 0 near the map border
    % or far from any occupied cell MAY be unknown in a SLAM context.
    %
    % For correctness in the ground-truth case (always binaryOccupancyMap),
    % we return all-false (no unknowns).
    %
    % For SLAM maps (also binaryOccupancyMap), we use the same logic.
    % A future improvement would pass the occupancyMap (non-binary) from
    % lidarSLAM which has probabilistic values, where 0.5 = truly unknown.

    mask = false(numRows, numCols);

    % Attempt to detect unknown cells: if the map class has a non-binary
    % occupancy layer (occupancyMap), we can check for cells at exactly 0.5.
    % binaryOccupancyMap does not expose this, so we skip.
    % This keeps the function correct for both map types.
end

function inUnknown = isUnknownCell(origGrid, inflatedMap, xy, numRows, resolution, xLimits, yLimits)
%ISUNKNOWNCELL Check if a world position corresponds to an unknown cell.
    col = round(xy(1) * resolution) + 1;
    row = numRows - round(xy(2) * resolution);
    row = max(1, min(numRows, row));
    col = max(1, min(size(origGrid, 2), col));
    % Unknown = not occupied in original AND not in bounds of known observations.
    % For binaryOccupancyMap: we cannot distinguish, so always return false.
    inUnknown = false;
end


% =====================================================================
% Helper: find nearest free cell when start is occupied
% =====================================================================
function rc = findNearestFree(grid, startRC, numRows, numCols)
%FINDNEARESTFREE BFS to find the nearest free cell from startRC.
    [freeR, freeC] = find(~grid);
    if isempty(freeR)
        rc = [];
        return;
    end
    dists = (freeR - startRC(1)).^2 + (freeC - startRC(2)).^2;
    [~, idx] = min(dists);
    rc = [freeR(idx), freeC(idx)];
end


% =====================================================================
% Path length computation
% =====================================================================
function L = pathLength(worldPath)
    if size(worldPath, 1) < 2
        L = 0;
        return;
    end
    diffs = diff(worldPath, 1, 1);
    L = sum(vecnorm(diffs, 2, 2));
end


% =====================================================================
% Struct defaults helper
% =====================================================================
function s = applyDefaults(s, defaults)
    fields = fieldnames(defaults);
    for i = 1:numel(fields)
        f = fields{i};
        if ~isfield(s, f) || isempty(s.(f))
            s.(f) = defaults.(f);
        end
    end
end
