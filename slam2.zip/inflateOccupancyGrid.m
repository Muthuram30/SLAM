function inflatedMap = inflateOccupancyGrid(map, inflationRadius)
%INFLATEOCCUPANCYGRID Inflate occupied cells in an occupancy map by a given radius.
%
%   inflatedMap = INFLATEOCCUPANCYGRID(map, inflationRadius)
%
%   Performs morphological dilation of the occupied cell set using a
%   circular structuring element of the specified radius.  Every free cell
%   within inflationRadius meters of any occupied cell is marked occupied
%   in the output map.
%
%   This is used by the A* global planner to create a configuration-space
%   map where the robot can be treated as a point and all obstacles are
%   pre-expanded by the robot radius + safety margin.
%
%   Inputs:
%       map             - binaryOccupancyMap (source map, not modified)
%       inflationRadius - dilation radius in meters (scalar, > 0)
%
%   Output:
%       inflatedMap - binaryOccupancyMap with same resolution and limits,
%                     occupied cells inflated by inflationRadius

    % ---------------------------------------------------------------
    % Input validation
    % ---------------------------------------------------------------
    validateattributes(inflationRadius, {'double'}, ...
        {'scalar', 'positive', 'finite'}, 'inflateOccupancyGrid', 'inflationRadius');

    resolution = map.Resolution;
    xLimits    = map.XWorldLimits;
    yLimits    = map.YWorldLimits;

    % ---------------------------------------------------------------
    % Get the raw occupancy grid (logical: true = occupied)
    % ---------------------------------------------------------------
    grid = logical(getOccupancy(map));
    [numRows, numCols] = size(grid);

    % ---------------------------------------------------------------
    % Build a circular structuring element for dilation.
    %
    % Radius in cells: ceil so we never under-inflate.
    % The structuring element SE(r,c) = 1 if the cell is within
    % inflationRadius of the center.
    % ---------------------------------------------------------------
    radiusCells = ceil(inflationRadius * resolution);
    seSize      = 2 * radiusCells + 1;          % odd-sized kernel
    [seC, seR]  = meshgrid(-radiusCells:radiusCells, -radiusCells:radiusCells);
    se          = (seR.^2 + seC.^2) <= radiusCells^2;  % circular mask

    % ---------------------------------------------------------------
    % Morphological dilation via imdilate (Image Processing Toolbox).
    % Fallback: manual dilation if IPT is unavailable.
    % ---------------------------------------------------------------
    if exist('imdilate', 'file') == 2
        inflatedGrid = imdilate(grid, se);
    else
        inflatedGrid = manualDilate(grid, se, numRows, numCols, seSize, radiusCells);
    end

    % ---------------------------------------------------------------
    % Build a new binaryOccupancyMap with the same geometry.
    %
    % XWorldLimits / YWorldLimits are READ-ONLY after construction in
    % newer Navigation Toolbox releases.  We must supply the correct
    % world origin to the constructor instead of assigning it later.
    %
    % binaryOccupancyMap(rows, cols, res, 'world') is NOT a valid
    % signature.  The only constructor that accepts an explicit origin is:
    %   binaryOccupancyMap(rows_m, cols_m, res)
    % which always places the lower-left corner at (0,0).
    %
    % To honour an arbitrary origin we:
    %   1. Create the map at the correct metric size.
    %   2. Call move() to shift the local frame so that XWorldLimits
    %      matches the source map exactly.
    % ---------------------------------------------------------------
    mapWidthM  = numCols / resolution;   % width  in metres
    mapHeightM = numRows / resolution;   % height in metres

    inflatedMap = binaryOccupancyMap(mapHeightM, mapWidthM, resolution);

    % Shift origin if the source map does not start at (0,0).
    % move(map, [dx dy]) translates the local frame of the map.
    dx = xLimits(1) - inflatedMap.XWorldLimits(1);
    dy = yLimits(1) - inflatedMap.YWorldLimits(1);
    if abs(dx) > 1e-9 || abs(dy) > 1e-9
        move(inflatedMap, [dx, dy]);
    end

    % setOccupancy expects logical or [0,1] values; pass the inflated grid.
    % binaryOccupancyMap convention: row 1 = max-y (top of map).
    % getOccupancy / setOccupancy share this convention, so we can pass
    % the grid directly.
    setOccupancy(inflatedMap, inflatedGrid);
end


% =====================================================================
% Fallback: manual morphological dilation (no Image Processing Toolbox)
% =====================================================================
function out = manualDilate(grid, se, numRows, numCols, seSize, radiusCells)
%MANUALDILATE Morphological dilation without imdilate.

    out = false(numRows, numCols);
    halfSE = radiusCells;

    % Find occupied cells
    [occRows, occCols] = find(grid);

    for k = 1:numel(occRows)
        r = occRows(k);
        c = occCols(k);

        % Determine the bounding box of the SE centered at (r, c)
        rMin = max(1, r - halfSE);
        rMax = min(numRows, r + halfSE);
        cMin = max(1, c - halfSE);
        cMax = min(numCols, c + halfSE);

        % Corresponding SE indices
        seRMin = rMin - r + halfSE + 1;
        seRMax = rMax - r + halfSE + 1;
        seCMin = cMin - c + halfSE + 1;
        seCMax = cMax - c + halfSE + 1;

        out(rMin:rMax, cMin:cMax) = out(rMin:rMax, cMin:cMax) | ...
                                    se(seRMin:seRMax, seCMin:seCMax);
    end
end
