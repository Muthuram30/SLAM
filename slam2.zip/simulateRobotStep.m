function [robot, controllerState, isPathComplete] = simulateRobotStep(robot, waypoints, controllerState, dt, waypointTolerance, map, collisionThreshold, lastScan, recoveryConfig, localPlannerConfig)
%SIMULATEROBOTSTEP Advance the robot one time step through the navigation pipeline.
%
%   [robot, controllerState, isPathComplete] = SIMULATEROBOTSTEP(robot, ...
%       waypoints, controllerState, dt, waypointTolerance, map, ...
%       collisionThreshold, lastScan, recoveryConfig, localPlannerConfig)
%
%   Navigation Pipeline (hierarchical mode, when controllerState.globalPath is set):
%       1. followPath         - extract lookahead carrot point from A* path
%       2. Controller         - compute velocity commands toward carrot point
%       3. Motion Model       - midpoint integration of the unicycle model
%       4. Collision Check    - check new pose (dynamic ring sampling)
%       5. Recovery FSM       - ROTATE / TRY_FORWARD / BACKUP (last resort)
%       6. State Update       - update robot struct with pose + diagnostics
%
%   Legacy mode (when controllerState.globalPath is empty):
%       Same pipeline but controller tracks waypoints directly.
%       Local planner path-blocking checks are active in legacy mode only.
%
%   New controllerState fields:
%       .globalPath  - Nx2 A* path in world frame ([] = legacy mode)
%       .pathIdx     - current index into globalPath (1-based)
%
%   New robot fields written:
%       .navMode      - 'GLOBAL_PATH'|'NAVIGATING'|'RECOVERY'|'PLANNING'
%       .needsReplan  - true when main.m should call planGlobalPath
%       .stuckCounter - consecutive blocked steps (reset on progress)
%
%   Inputs:  (unchanged from previous version for full backward compatibility)
%       robot               - robot struct from createRobot.m
%       waypoints           - Nx2 matrix of [x y] global coverage waypoints
%       controllerState     - struct with .currentWaypointIdx (+ optional globalPath/pathIdx)
%       dt                  - time step (s)
%       waypointTolerance   - distance at which a waypoint counts as reached
%       map                 - binaryOccupancyMap for collision checking
%       collisionThreshold  - recovery cycles before current waypoint is skipped
%       lastScan            - (optional) lidarScan from simulateLiDAR
%       recoveryConfig      - (optional) config.recovery struct
%       localPlannerConfig  - (optional) config.localPlanner struct
%           New fields used from localPlannerConfig:
%               .pathFollowLookahead - carrot lookahead distance (m), default 0.40
%               .pathFollowTolerance - path-point reach tolerance (m), default 0.20
%               .stuckTimeout        - steps before recovery escalation, default collisionThreshold

    % ---------------------------------------------------------------
    % Defaults and input validation
    % ---------------------------------------------------------------
    if nargin < 7 || isempty(collisionThreshold)
        collisionThreshold = 50;
    end
    if nargin < 8;  lastScan           = [];  end
    if nargin < 9;  recoveryConfig     = [];  end
    if nargin < 10; localPlannerConfig = [];  end

    hasAnalyzer     = ~isempty(lastScan) && ~isempty(recoveryConfig);
    hasLocalPlanner = ~isempty(localPlannerConfig);

    validateattributes(waypoints, {'double'}, {'2d', 'ncols', 2});
    validateattributes(dt, {'double'}, {'scalar', 'positive', 'finite'});
    validateattributes(waypointTolerance, {'double'}, {'scalar', 'positive', 'finite'});

    numWaypoints = size(waypoints, 1);

    % Ensure new robot fields exist (backward compat with old robot structs)
    if ~isfield(robot, 'needsReplan');  robot.needsReplan  = false; end
    if ~isfield(robot, 'navMode');      robot.navMode      = 'NAVIGATING'; end
    if ~isfield(robot, 'stuckCounter'); robot.stuckCounter = 0; end

    % Ensure new controllerState fields exist
    if ~isfield(controllerState, 'globalPath'); controllerState.globalPath = []; end
    if ~isfield(controllerState, 'pathIdx');    controllerState.pathIdx    = 1; end

    % ---------------------------------------------------------------
    % Determine operating mode
    % ---------------------------------------------------------------
    % Hierarchical mode: a global A* path is loaded and the controller
    % follows it via lookahead carrot points.
    % Legacy mode: direct waypoint tracking (original behavior).
    hierarchical = ~isempty(controllerState.globalPath);

    % Lookahead parameters (from localPlannerConfig if available)
    if hasLocalPlanner && isfield(localPlannerConfig, 'pathFollowLookahead') ...
            && ~isempty(localPlannerConfig.pathFollowLookahead)
        lookaheadDist = localPlannerConfig.pathFollowLookahead;
    else
        lookaheadDist = 0.40;
    end
    if hasLocalPlanner && isfield(localPlannerConfig, 'pathFollowTolerance') ...
            && ~isempty(localPlannerConfig.pathFollowTolerance)
        pathPointTol = localPlannerConfig.pathFollowTolerance;
    else
        pathPointTol = max(0.18, waypointTolerance * 1.2);
    end
    if hasLocalPlanner && isfield(localPlannerConfig, 'stuckTimeout') ...
            && ~isempty(localPlannerConfig.stuckTimeout)
        stuckTimeout = localPlannerConfig.stuckTimeout;
    else
        stuckTimeout = collisionThreshold;
    end

    followCfg = struct('waypointTolerance', pathPointTol, 'lookaheadDist', lookaheadDist);

    % Nothing to do if path is empty or already finished.
    if numWaypoints == 0 || controllerState.currentWaypointIdx > numWaypoints
        robot.linearVel      = 0;
        robot.angularVel     = 0;
        robot.targetWaypoint = [NaN, NaN];
        robot.distanceToGoal = NaN;
        robot.headingError   = NaN;
        robot.navigationState= 'COMPLETED';
        robot.navMode        = 'COMPLETED';
        isPathComplete       = true;
        return;
    end

    isPathComplete = false;

    % ---------------------------------------------------------------
    % Navigation Finite State Machine
    % ---------------------------------------------------------------
    switch robot.navigationState

        case "NAVIGATING"

            currentGlobalWaypoint = waypoints(controllerState.currentWaypointIdx, :);

            % ---------------------------------------------------
            % Choose tracking target based on operating mode
            % ---------------------------------------------------
            if hierarchical
                % ------------------------------------------------
                % HIERARCHICAL MODE: follow A* path via carrot point
                % ------------------------------------------------
                [trackingPoint, newPathIdx, pathExhausted] = followPath( ...
                    controllerState.globalPath, robot.pose, ...
                    controllerState.pathIdx, followCfg);
                controllerState.pathIdx = newPathIdx;

                if pathExhausted
                    % All path points reached → global waypoint done.
                    % Signal main.m to plan to the next waypoint.
                    controllerState.currentWaypointIdx = ...
                        controllerState.currentWaypointIdx + 1;
                    controllerState.globalPath = [];
                    controllerState.pathIdx    = 1;
                    robot.needsReplan  = true;
                    robot.navMode      = 'PLANNING';
                    robot.stuckCounter = 0;

                    if controllerState.currentWaypointIdx > numWaypoints
                        isPathComplete = true;
                    end
                    % No motion command this step (planning step)
                    robot.linearVel  = 0;
                    robot.angularVel = 0;
                    return;
                end

                targetWaypoint = trackingPoint;
                robot.navMode  = 'GLOBAL_PATH';

            else
                % ------------------------------------------------
                % LEGACY MODE: direct waypoint tracking
                % ------------------------------------------------
                targetWaypoint = currentGlobalWaypoint;
                robot.navMode  = 'NAVIGATING';

                % Legacy local planner: check if direct path is blocked
                % and generate temporary waypoints if needed.
                if hasLocalPlanner
                    if ~isfield(robot, 'localPlannerState')
                        robot.localPlannerState = struct( ...
                            'active', false, ...
                            'tempWaypoint', [], ...
                            'originalWaypoint', [], ...
                            'replanCounter', 0, ...
                            'prevTempWaypoint', [], ...
                            'tempWpHistory', zeros(0, 2));
                    end

                    lpState = robot.localPlannerState;

                    if lpState.active
                        tempWp = lpState.tempWaypoint;
                        origWp = lpState.originalWaypoint;
                        distToTemp = norm(robot.pose(1:2) - tempWp);
                        distToOrig = norm(robot.pose(1:2) - origWp);
                        tempToOrig = norm(tempWp - origWp);
                        tempTolerance = localPlannerConfig.waypointTolerance;
                        if isempty(tempTolerance); tempTolerance = waypointTolerance * 1.5; end

                        directPathClear = ~isPathBlocked(map, robot.pose, origWp, ...
                            robot.safetyRadius, localPlannerConfig);

                        if distToTemp <= tempTolerance || directPathClear
                            lpState.active = false;
                            lpState.tempWaypoint = [];
                            lpState.originalWaypoint = [];
                            lpState.replanCounter = 0;
                        elseif distToOrig < tempToOrig - 0.1
                            lpState.active = false;
                            lpState.tempWaypoint = [];
                            lpState.originalWaypoint = [];
                            lpState.replanCounter = 0;
                        elseif ~checkCollision(map, [tempWp, robot.pose(3)], robot.safetyRadius + localPlannerConfig.minClearance)
                            lpState.active = false;
                        else
                            targetWaypoint = tempWp;
                            lpState.replanCounter = lpState.replanCounter + 1;
                        end
                    else
                        pathBlocked = isPathBlocked(map, robot.pose, targetWaypoint, ...
                            robot.safetyRadius, localPlannerConfig);
                        if pathBlocked
                            [tempWaypoint, ~] = localPlanner( ...
                                map, robot.pose, targetWaypoint, robot.safetyRadius, ...
                                localPlannerConfig, lpState.prevTempWaypoint, lastScan, ...
                                robot.recoveryAnalysis);
                            if ~isempty(tempWaypoint)
                                lpState.active           = true;
                                lpState.tempWaypoint     = tempWaypoint;
                                lpState.originalWaypoint = targetWaypoint;
                                lpState.replanCounter    = 0;
                                lpState.prevTempWaypoint = tempWaypoint;
                                targetWaypoint           = tempWaypoint;
                                if isfield(localPlannerConfig, 'tempWpHistorySize') && ~isempty(localPlannerConfig.tempWpHistorySize)
                                    histSize = localPlannerConfig.tempWpHistorySize;
                                else
                                    histSize = 8;  % default: keep last 8 temp waypoints
                                end
                                lpState.tempWpHistory = [lpState.tempWpHistory; tempWaypoint];
                                if size(lpState.tempWpHistory, 1) > histSize
                                    lpState.tempWpHistory = lpState.tempWpHistory(end-histSize+1:end, :);
                                end
                            end
                        end
                    end
                    robot.localPlannerState = lpState;
                end
            end

            % ---------------------------------------------------
            % Controller → Motion → Collision
            % ---------------------------------------------------
            [linearVel, angularVel, distanceToTarget, headingError] = ...
                computeControlCommands(robot, targetWaypoint);

            newPose = applyMotionModel(robot.pose, linearVel, angularVel, dt);
            isSafe  = checkCollision(map, newPose, robot.safetyRadius);

            if isSafe
                robot.pose         = newPose;
                robot.collisionCounter = 0;
                robot.stuckCounter = 0;
                robot.navigationState  = "NAVIGATING";

                distanceToTarget = norm(robot.pose(1:2) - targetWaypoint);

                if hierarchical
                    % Hierarchical: check proximity to global waypoint
                    % as a belt-and-suspenders advance trigger.
                    distToGlobal = norm(robot.pose(1:2) - currentGlobalWaypoint);
                    if distToGlobal <= waypointTolerance
                        controllerState.currentWaypointIdx = ...
                            controllerState.currentWaypointIdx + 1;
                        controllerState.globalPath = [];
                        controllerState.pathIdx    = 1;
                        robot.needsReplan  = true;
                        robot.navMode      = 'PLANNING';
                        robot.stuckCounter = 0;
                        if controllerState.currentWaypointIdx > numWaypoints
                            isPathComplete = true;
                        end
                    end
                else
                    % Legacy: direct distance check
                    if distanceToTarget <= waypointTolerance
                        controllerState.currentWaypointIdx = ...
                            controllerState.currentWaypointIdx + 1;
                        if controllerState.currentWaypointIdx > numWaypoints
                            isPathComplete = true;
                        end
                    end
                end

            else
                % ---------------------------------------------------
                % Collision: escalate to recovery FSM
                % ---------------------------------------------------
                robot.stuckCounter     = robot.stuckCounter + 1;
                robot.recoveryTimer    = 0;
                robot.collisionCounter = robot.collisionCounter + 1;
                robot.recoveryStartHeading = robot.pose(3);
                robot.navMode = 'RECOVERY';

                if hasAnalyzer
                    recov = analyzeRecovery(map, lastScan, robot.pose, recoveryConfig, ...
                        robot.recoveryAnalysis, targetWaypoint);
                    robot.recoveryAnalysis = recov;

                    if recov.direction == 0
                        robot.navigationState = "BACKUP";
                        robot.backupDistance  = 0;
                    elseif recov.direction > 0
                        robot.navigationState   = "ROTATE_LEFT";
                        robot.recoveryDirection = 1;
                        robot.targetRecoveryHeading = ...
                            wrapAngleToPi(robot.pose(3) + recov.angle);
                    else
                        robot.navigationState   = "ROTATE_RIGHT";
                        robot.recoveryDirection = -1;
                        robot.targetRecoveryHeading = ...
                            wrapAngleToPi(robot.pose(3) - recov.angle);
                    end
                else
                    robot.navigationState   = "ROTATE_LEFT";
                    robot.recoveryDirection = 1;
                    robot.targetRecoveryHeading = ...
                        wrapAngleToPi(robot.pose(3) + deg2rad(25));
                end

                linearVel  = 0;
                angularVel = 0;
            end

        case "ROTATE_LEFT"
            robot.navMode = 'RECOVERY';
            linearVel  = 0;
            angularVel = 0.6 * robot.maxAngularVel;

            newPose = applyMotionModel(robot.pose, linearVel, angularVel, dt);

            if checkCollision(map, newPose, robot.safetyRadius)
                robot.pose         = newPose;
                robot.recoveryTimer = robot.recoveryTimer + 1;

                angleRemaining = wrapAngleToPi(robot.targetRecoveryHeading - robot.pose(3));

                if abs(angleRemaining) < deg2rad(3)
                    if hasAnalyzer
                        probePose = applyMotionModel(robot.pose, 0.2 * robot.maxLinearVel, 0, dt);
                        if checkCollision(map, probePose, robot.safetyRadius)
                            robot.navigationState = "TRY_FORWARD";
                            robot.recoveryTimer   = 0;
                        elseif robot.recoveryTimer > recoveryConfig.maxRotateSteps
                            newRecov = analyzeRecovery(map, lastScan, robot.pose, recoveryConfig, ...
                                robot.recoveryAnalysis, waypoints(controllerState.currentWaypointIdx,:));
                            robot.navigationState = "ROTATE_RIGHT";
                            robot.targetRecoveryHeading = ...
                                wrapAngleToPi(robot.pose(3) - newRecov.angle);
                            robot.recoveryTimer = 0;
                        else
                            newRecov = analyzeRecovery(map, lastScan, robot.pose, recoveryConfig, ...
                                robot.recoveryAnalysis, waypoints(controllerState.currentWaypointIdx,:));
                            if newRecov.direction >= 0
                                robot.targetRecoveryHeading = ...
                                    wrapAngleToPi(robot.pose(3) + newRecov.angle);
                            else
                                robot.navigationState = "ROTATE_RIGHT";
                                robot.targetRecoveryHeading = ...
                                    wrapAngleToPi(robot.pose(3) - newRecov.angle);
                                robot.recoveryTimer = 0;
                            end
                        end
                    else
                        robot.navigationState = "TRY_FORWARD";
                        robot.recoveryTimer   = 0;
                    end
                end
            else
                robot.recoveryTimer = 0;
                if hasAnalyzer
                    newRecov = analyzeRecovery(map, lastScan, robot.pose, recoveryConfig, ...
                        robot.recoveryAnalysis, waypoints(controllerState.currentWaypointIdx,:));
                    robot.targetRecoveryHeading = ...
                        wrapAngleToPi(robot.pose(3) - newRecov.angle);
                else
                    robot.targetRecoveryHeading = ...
                        wrapAngleToPi(robot.pose(3) - deg2rad(25));
                end
                robot.navigationState = "ROTATE_RIGHT";
            end

            distanceToTarget = robot.distanceToGoal;
            headingError     = robot.headingError;
            targetWaypoint   = waypoints(controllerState.currentWaypointIdx,:);

        case "TRY_FORWARD"
            robot.navMode  = 'RECOVERY';
            targetWaypoint = waypoints(controllerState.currentWaypointIdx, :);

            [linearVel, angularVel, distanceToTarget, headingError] = ...
                computeControlCommands(robot, targetWaypoint);
            linearVel  = 0.35 * robot.maxLinearVel;
            angularVel = 0;

            newPose = applyMotionModel(robot.pose, linearVel, angularVel, dt);

            if checkCollision(map, newPose, robot.safetyRadius)
                robot.pose            = newPose;
                robot.navigationState = "NAVIGATING";
                robot.collisionCounter = 0;
                robot.stuckCounter    = 0;
                robot.navMode         = 'GLOBAL_PATH';

                % Recovery succeeded: signal main.m to replan.
                % The robot may have moved off the original A* path during
                % recovery, so a fresh plan from the current pose is needed.
                robot.needsReplan = true;

                if hasAnalyzer
                    robot.recoveryAnalysis.failedAttempts = 0;
                    robot.recoveryAnalysis.deadEndCount   = 0;
                    robot.recoveryAnalysis.lastDirection  = 0;
                    robot.recoveryAnalysis.lastEnvType    = 'UNKNOWN';
                end

                distanceToTarget = norm(robot.pose(1:2) - targetWaypoint);
                if distanceToTarget <= waypointTolerance
                    controllerState.currentWaypointIdx = ...
                        controllerState.currentWaypointIdx + 1;
                    controllerState.globalPath = [];
                    controllerState.pathIdx    = 1;
                    if controllerState.currentWaypointIdx > numWaypoints
                        isPathComplete = true;
                    end
                end
            else
                robot.recoveryTimer = 0;
                if hasAnalyzer
                    robot.recoveryAnalysis.failedAttempts = ...
                        robot.recoveryAnalysis.failedAttempts + 1;
                    newRecov = analyzeRecovery(map, lastScan, robot.pose, recoveryConfig, ...
                        robot.recoveryAnalysis, waypoints(controllerState.currentWaypointIdx,:));
                    robot.recoveryAnalysis = newRecov;
                    if newRecov.direction >= 0
                        robot.navigationState = "ROTATE_LEFT";
                        robot.targetRecoveryHeading = ...
                            wrapAngleToPi(robot.pose(3) + newRecov.angle);
                    else
                        robot.navigationState = "ROTATE_RIGHT";
                        robot.targetRecoveryHeading = ...
                            wrapAngleToPi(robot.pose(3) - newRecov.angle);
                    end
                else
                    robot.navigationState = "ROTATE_RIGHT";
                    robot.targetRecoveryHeading = ...
                        wrapAngleToPi(robot.pose(3) - deg2rad(25));
                end
                linearVel  = 0;
                angularVel = 0;
            end

        case "ROTATE_RIGHT"
            robot.navMode  = 'RECOVERY';
            linearVel  = 0;
            angularVel = -0.6 * robot.maxAngularVel;

            newPose = applyMotionModel(robot.pose, linearVel, angularVel, dt);

            if checkCollision(map, newPose, robot.safetyRadius)
                robot.pose          = newPose;
                robot.recoveryTimer = robot.recoveryTimer + 1;

                angleRemaining = wrapAngleToPi(robot.targetRecoveryHeading - robot.pose(3));

                if abs(angleRemaining) < deg2rad(3)
                    if hasAnalyzer
                        probePose = applyMotionModel(robot.pose, 0.2 * robot.maxLinearVel, 0, dt);
                        if checkCollision(map, probePose, robot.safetyRadius)
                            robot.navigationState = "TRY_FORWARD";
                        else
                            robot.navigationState = "BACKUP";
                        end
                    else
                        robot.navigationState = "BACKUP";
                    end
                    robot.recoveryTimer  = 0;
                    robot.backupDistance = 0;
                end
            else
                robot.navigationState = "BACKUP";
                robot.recoveryTimer   = 0;
                robot.backupDistance  = 0;
            end

            targetWaypoint   = waypoints(controllerState.currentWaypointIdx, :);
            distanceToTarget = robot.distanceToGoal;
            headingError     = robot.headingError;

        case "BACKUP"
            robot.navMode = 'RECOVERY';
            linearVel  = -0.25 * robot.maxLinearVel;
            angularVel = 0;

            newPose = applyMotionModel(robot.pose, linearVel, angularVel, dt);

            if checkCollision(map, newPose, robot.safetyRadius)
                robot.pose           = newPose;
                robot.backupDistance = robot.backupDistance + abs(linearVel * dt);

                if robot.backupDistance >= 0.25
                    robot.navigationState = "TRY_FORWARD";
                end
            else
                if robot.collisionCounter >= collisionThreshold
                    fprintf('Recovery failed after %d cycles. Skipping waypoint %d\n', ...
                        robot.collisionCounter, controllerState.currentWaypointIdx);

                    controllerState.currentWaypointIdx = ...
                        controllerState.currentWaypointIdx + 1;
                    controllerState.globalPath = [];   % force replan for new waypoint
                    controllerState.pathIdx    = 1;
                    robot.needsReplan  = true;         % signal main.m to plan
                    robot.navMode      = 'PLANNING';
                    robot.navigationState = "NAVIGATING";
                    robot.collisionCounter = 0;
                    robot.stuckCounter     = 0;
                    robot.backupDistance   = 0;

                    if controllerState.currentWaypointIdx > numWaypoints
                        isPathComplete = true;
                    end
                else
                    robot.recoveryTimer        = 0;
                    robot.recoveryStartHeading = robot.pose(3);
                    robot.backupDistance        = 0;

                    if hasAnalyzer
                        newRecov = analyzeRecovery(map, lastScan, robot.pose, recoveryConfig, ...
                            robot.recoveryAnalysis, waypoints(controllerState.currentWaypointIdx,:));
                        if newRecov.direction >= 0
                            robot.navigationState = "ROTATE_LEFT";
                            robot.targetRecoveryHeading = ...
                                wrapAngleToPi(robot.pose(3) + newRecov.angle);
                        else
                            robot.navigationState = "ROTATE_RIGHT";
                            robot.targetRecoveryHeading = ...
                                wrapAngleToPi(robot.pose(3) - newRecov.angle);
                        end
                    else
                        robot.navigationState = "ROTATE_LEFT";
                        robot.targetRecoveryHeading = ...
                            wrapAngleToPi(robot.pose(3) + deg2rad(25));
                    end
                end
            end

            targetWaypoint   = waypoints(controllerState.currentWaypointIdx, :);
            distanceToTarget = robot.distanceToGoal;
            headingError     = robot.headingError;

        otherwise
            robot.navigationState = "NAVIGATING";
    end

    % ---------------------------------------------------------------
    % State Update — populate diagnostics
    % ---------------------------------------------------------------
    if exist('linearVel', 'var')
        robot.linearVel = linearVel;
    else
        robot.linearVel = 0;
    end

    if exist('angularVel', 'var')
        robot.angularVel = angularVel;
    else
        robot.angularVel = 0;
    end

    if exist('targetWaypoint', 'var')
        robot.targetWaypoint = targetWaypoint;
    end

    if exist('distanceToTarget', 'var')
        robot.distanceToGoal = distanceToTarget;
    end

    if exist('headingError', 'var')
        robot.headingError = headingError;
    end
end

% =====================================================================
% Stage 1: Controller
% =====================================================================

function [linearVel, angularVel, distanceToTarget, headingError] = computeControlCommands(robot, targetWaypoint)
%COMPUTECONTROLCOMMANDS Proportional heading controller with speed shaping.

    headingGain          = 2.0;
    slowdownRadius       = 0.6;
    headingSlowdownAngle = pi / 3;

    currentPose = robot.pose;

    deltaX = targetWaypoint(1) - currentPose(1);
    deltaY = targetWaypoint(2) - currentPose(2);
    distanceToTarget = hypot(deltaX, deltaY);

    desiredHeading = atan2(deltaY, deltaX);
    headingError   = wrapAngleToPi(desiredHeading - currentPose(3));

    angularVel = headingGain * headingError;
    angularVel = max(-robot.maxAngularVel, min(robot.maxAngularVel, angularVel));

    headingThrottle  = max(0, 1 - abs(headingError) / headingSlowdownAngle);
    proximityThrottle = min(1, distanceToTarget / slowdownRadius);
    linearVel = robot.maxLinearVel * headingThrottle * proximityThrottle;
    linearVel = max(0, min(robot.maxLinearVel, linearVel));
end

% =====================================================================
% Stage 2: Motion Model (Midpoint Integration)
% =====================================================================

function newPose = applyMotionModel(pose, linearVel, angularVel, dt)
%APPLYMOTIONMODEL Midpoint integration of the unicycle kinematic model.
    thetaHalf = pose(3) + 0.5 * angularVel * dt;
    newX      = pose(1) + linearVel * cos(thetaHalf) * dt;
    newY      = pose(2) + linearVel * sin(thetaHalf) * dt;
    newTheta  = wrapAngleToPi(pose(3) + angularVel * dt);
    newPose   = [newX, newY, newTheta];
end

% =====================================================================
% Stage 3: Collision Check (Dynamic Ring Sampling)
% =====================================================================

function isSafe = checkCollision(map, pose, safetyRadius)
%CHECKCOLLISION Check whether a candidate pose is collision-free.
    xLimits = map.XWorldLimits;
    yLimits = map.YWorldLimits;

    if pose(1) < xLimits(1) || pose(1) > xLimits(2) || ...
       pose(2) < yLimits(1) || pose(2) > yLimits(2)
        isSafe = false;
        return;
    end

    numRingSamples = max(12, ceil(2 * pi * safetyRadius * map.Resolution));
    angles = linspace(0, 2*pi, numRingSamples + 1);
    angles(end) = [];

    samplePoints = [pose(1), pose(2)];
    for k = 1:numRingSamples
        pt = [pose(1) + safetyRadius * cos(angles(k)), ...
              pose(2) + safetyRadius * sin(angles(k))];
        if pt(1) >= xLimits(1) && pt(1) <= xLimits(2) && ...
           pt(2) >= yLimits(1) && pt(2) <= yLimits(2)
            samplePoints(end+1, :) = pt; %#ok<AGROW>
        else
            isSafe = false;
            return;
        end
    end

    occupiedFlags = checkOccupancy(map, samplePoints);
    isSafe = ~any(occupiedFlags);
end

% =====================================================================
% Shared helper
% =====================================================================

function wrapped = wrapAngleToPi(angle)
%WRAPANGLETOPI Wrap angle to (-pi, pi].
    wrapped = atan2(sin(angle), cos(angle));
end

% =====================================================================
% Legacy Local Planner helpers (used in legacy mode only)
% =====================================================================

function blocked = isPathBlocked(map, robotPose, targetWaypoint, safetyRadius, config)
%ISPATHBLOCKED Check if direct path to waypoint is collision-free.
    if nargin < 5 || isempty(config); config = struct(); end

    resolution = config.pathCheckResolution;
    if isempty(resolution) || resolution <= 0; resolution = 0.1; end

    inflation = config.pathCheckInflation;
    if isempty(inflation); inflation = 0.15; end

    checkRadius = safetyRadius + inflation;
    vec  = targetWaypoint - robotPose(1:2);
    dist = norm(vec);

    if dist < 1e-6; blocked = false; return; end

    numSamples   = max(2, ceil(dist / resolution));
    t            = linspace(0, 1, numSamples)';
    samplePoints = robotPose(1:2) + t * vec;

    for i = 1:numSamples
        dummyPose = [samplePoints(i, :), robotPose(3)];
        if ~checkCollision(map, dummyPose, checkRadius)
            blocked = true;
            return;
        end
    end
    blocked = false;
end
