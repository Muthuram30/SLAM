function [trackingPoint, newPathIdx, pathComplete] = followPath(path, robotPose, pathIdx, config)
%FOLLOWPATH Extract the next tracking (carrot) point from a planned path.
%
%   [trackingPoint, newPathIdx, pathComplete] = FOLLOWPATH(path, robotPose, pathIdx, config)
%
%   Implements a lookahead carrot-point controller:
%     1. Advance pathIdx past any path points the robot has already reached
%        (within config.waypointTolerance).
%     2. Walk forward along the path from pathIdx, accumulating arc length,
%        until config.lookaheadDist meters of path have been counted.
%     3. Return the interpolated carrot point at exactly lookaheadDist ahead.
%
%   If the lookahead extends beyond the last path point, the last point is
%   returned (the robot simply drives to the end of the path).
%
%   The controller that receives trackingPoint is agnostic to whether this
%   came from A* or any other planner — it simply steers toward it.
%
%   Inputs:
%       path      - Nx2 world-frame [x y] planned path (N >= 1)
%       robotPose - 1×3 [x y theta] current robot pose
%       pathIdx   - current path tracking index (1-based)
%       config    - struct with:
%           .waypointTolerance  - distance to consider a path point reached (m)
%           .lookaheadDist      - carrot lookahead distance (m)
%
%   Outputs:
%       trackingPoint - 1×2 [x y] target point for the controller
%       newPathIdx    - updated path index (may have advanced)
%       pathComplete  - true when all path points have been reached

    % ---------------------------------------------------------------
    % Trivial cases
    % ---------------------------------------------------------------
    if isempty(path)
        trackingPoint = [];
        newPathIdx    = pathIdx;
        pathComplete  = true;
        return;
    end

    % Default config
    if nargin < 4 || isempty(config)
        config = struct();
    end
    if ~isfield(config, 'waypointTolerance') || isempty(config.waypointTolerance)
        config.waypointTolerance = 0.20;
    end
    if ~isfield(config, 'lookaheadDist') || isempty(config.lookaheadDist)
        config.lookaheadDist = 0.40;
    end

    n       = size(path, 1);
    robotXY = robotPose(1:2);
    tol     = config.waypointTolerance;
    lookahead = config.lookaheadDist;

    % ---------------------------------------------------------------
    % Step 1: Advance pathIdx past points the robot has already reached.
    %
    % A point is "reached" when the robot is within waypointTolerance of it.
    % We keep advancing as long as the NEXT point is also within tolerance,
    % to avoid getting stuck re-approaching an already-passed cluster.
    % ---------------------------------------------------------------
    pathIdx = max(1, min(pathIdx, n));  % clamp

    while pathIdx <= n && norm(robotXY - path(pathIdx, :)) <= tol
        pathIdx = pathIdx + 1;
    end

    % ---------------------------------------------------------------
    % Step 2: Check if path is complete
    % ---------------------------------------------------------------
    if pathIdx > n
        trackingPoint = path(n, :);
        newPathIdx    = pathIdx;
        pathComplete  = true;
        return;
    end

    % ---------------------------------------------------------------
    % Step 3: Walk forward from pathIdx, accumulate arc length.
    %
    % Start accumulating from the robot's projection onto the current
    % path segment.  We use the robot's current position as the "previous
    % point" so the carrot distance is measured from where we ARE, not
    % from the path node behind us.
    % ---------------------------------------------------------------
    prevPt   = robotXY;
    accDist  = 0;

    for i = pathIdx:n
        currPt  = path(i, :);
        segDist = norm(currPt - prevPt);

        if accDist + segDist >= lookahead
            % Carrot point is on this segment
            remaining = lookahead - accDist;
            if segDist > 1e-9
                dir = (currPt - prevPt) / segDist;
            else
                dir = [cos(robotPose(3)), sin(robotPose(3))];  % fallback
            end
            trackingPoint = prevPt + remaining * dir;
            newPathIdx    = pathIdx;
            pathComplete  = false;
            return;
        end

        accDist = accDist + segDist;
        prevPt  = currPt;
    end

    % ---------------------------------------------------------------
    % Lookahead extends beyond path end → return last path point
    % ---------------------------------------------------------------
    trackingPoint = path(n, :);
    newPathIdx    = pathIdx;
    pathComplete  = false;
end
