function [isValid, firstBlockedSeg] = validatePath(path, map, config)
%VALIDATEPATH Check whether a planned path is still collision-free.
%
%   [isValid, firstBlockedSeg] = VALIDATEPATH(path, map, config)
%
%   Samples points along each path segment and checks occupancy with a
%   circular footprint of radius config.pathCheckRadius.  Returns as soon
%   as the first blocked segment is found (fast early exit).
%
%   Called by the main navigation manager whenever the occupancy map has
%   been updated, to decide whether the current A* path needs replanning.
%
%   Inputs:
%       path   - Nx2 world-frame [x y] path from planGlobalPath (N >= 2)
%       map    - binaryOccupancyMap (current planning map)
%       config - struct with fields:
%           .pathCheckRadius     - footprint radius for sampling (m)
%           .pathCheckResolution - sample spacing along each segment (m)
%
%   Outputs:
%       isValid         - true if every segment is collision-free
%       firstBlockedSeg - index of the first blocked segment (0 = none)

    % ---------------------------------------------------------------
    % Defaults and trivial cases
    % ---------------------------------------------------------------
    if nargin < 3 || isempty(config)
        config = struct();
    end
    if ~isfield(config, 'pathCheckRadius') || isempty(config.pathCheckRadius)
        config.pathCheckRadius = 0.22;
    end
    if ~isfield(config, 'pathCheckResolution') || isempty(config.pathCheckResolution)
        config.pathCheckResolution = 0.1;
    end

    if isempty(path) || size(path, 1) < 2
        isValid = true;
        firstBlockedSeg = 0;
        return;
    end

    n              = size(path, 1);
    checkRadius    = config.pathCheckRadius;
    sampleSpacing  = config.pathCheckResolution;

    xLimits = map.XWorldLimits;
    yLimits = map.YWorldLimits;

    % ---------------------------------------------------------------
    % Check each segment
    % ---------------------------------------------------------------
    for seg = 1:(n - 1)
        p1  = path(seg, :);
        p2  = path(seg + 1, :);
        vec = p2 - p1;
        d   = norm(vec);

        if d < 1e-6
            continue;
        end

        numSamples = max(2, ceil(d / sampleSpacing));
        t = linspace(0, 1, numSamples)';
        pts = p1 + t * vec;

        for k = 1:numSamples
            px = pts(k, 1);
            py = pts(k, 2);

            % Bounds check
            if px < xLimits(1) || px > xLimits(2) || ...
               py < yLimits(1) || py > yLimits(2)
                isValid = false;
                firstBlockedSeg = seg;
                return;
            end

            % Ring of points at checkRadius around sample
            numRing = max(6, ceil(2 * pi * checkRadius * map.Resolution));
            ringAngles = linspace(0, 2*pi, numRing + 1);
            ringAngles(end) = [];

            ringPts = [px + checkRadius * cos(ringAngles)', ...
                       py + checkRadius * sin(ringAngles)'];

            % Clip ring points to map bounds before batch check
            inBounds = ringPts(:,1) >= xLimits(1) & ringPts(:,1) <= xLimits(2) & ...
                       ringPts(:,2) >= yLimits(1) & ringPts(:,2) <= yLimits(2);

            if ~all(inBounds)
                isValid = false;
                firstBlockedSeg = seg;
                return;
            end

            % Batch occupancy query (most efficient path through the map API)
            allPts = [px, py; ringPts];
            occ    = checkOccupancy(map, allPts);
            if any(occ)
                isValid = false;
                firstBlockedSeg = seg;
                return;
            end
        end
    end

    isValid = true;
    firstBlockedSeg = 0;
end
